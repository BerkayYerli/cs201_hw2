#include "Calculator.h"

void add(Stack* stack, Stack* operatorStack, const string& item) {
    auto* stackItem = new StackItem(item);

    if (!stackItem->isOperator)
        stack->push(stackItem);
    else if (operatorStack->isEmpty() || stackItem->op == OPERATOR_LEFTPAR || operatorStack->top().op == OPERATOR_LEFTPAR)
        operatorStack->push(stackItem);
    else if (stackItem->op == OPERATOR_RIGHTPAR) {
        delete stackItem;

        for (auto i = operatorStack->pop(); i.op != OPERATOR_LEFTPAR; i = operatorStack->pop())
            stack->push(new StackItem(true, i.op));

    } else if (stackItem->op == OPERATOR_MULTIPLICATION || stackItem->op == OPERATOR_DIVISION) {
        if (operatorStack->top().op == OPERATOR_MULTIPLICATION || operatorStack->top().op == OPERATOR_DIVISION) {
            auto previous = operatorStack->pop();

            operatorStack->push(stackItem);

            stack->push(new StackItem(true, previous.op));
        } else
            operatorStack->push(stackItem);
    } else {
        auto previous = operatorStack->pop();

        operatorStack->push(stackItem);

        stack->push(new StackItem(true, previous.op));
    }
}

string generatePostfix(const Stack* stack) {
    string postfix;

    for (auto* node = stack->getRoot(); node != nullptr; node = node->next)
        postfix = node->toString() + " " + postfix;

    postfix += ";";

    return postfix;
}

Calculator::Calculator(string infix) {
    infixExpression = infix;

    stack = new Stack();
    auto* operatorStack = new Stack();

    stringstream ss(infix);

    for (string item; ss >> item; )
        add(stack, operatorStack, item);

    while (!operatorStack->isEmpty())
        stack->push(new StackItem(true, operatorStack->pop().op));

    delete operatorStack;

    postfixExpression = generatePostfix(stack);
}

Calculator::~Calculator() {
    delete stack;
}

string Calculator::getPostfix() {
    return postfixExpression;
}

Stack* reversed(const Stack* stack) {
    auto* reversedStack = new Stack();

    for (auto* node = stack->getRoot(); node != nullptr; node = node->next)
        reversedStack->push(new StackItem(node->toString()));

    return reversedStack;
}

int Calculator::calculate() {
    auto* calculator = new Stack();
    auto* reversedStack = reversed(stack);

    while (!reversedStack->isEmpty()) {
        auto item = reversedStack->pop();

        if (!item.isOperator) {
            calculator->push(new StackItem(false, item.n));
            continue;
        }

        auto number2 = calculator->pop().n;
        auto number1 = calculator->pop().n;

        switch (item.op) {
            case OPERATOR_PLUS:
                calculator->push(new StackItem(false, number1 + number2));
                break;
            case OPERATOR_MINUS:
                calculator->push(new StackItem(false, number1 - number2));
                break;
            case OPERATOR_MULTIPLICATION:
                calculator->push(new StackItem(false, number1 * number2));
                break;
            case OPERATOR_DIVISION:
                calculator->push(new StackItem(false, number1 / number2));
                break;
        }
    }

    auto result = calculator->pop().n;

    delete calculator;
    delete reversedStack;

    return result;
}