#include "Stack.h"

Stack::Stack() {
    root = nullptr;
}

Stack::~Stack() {
    if (root == nullptr)
        return;

    for (auto* temp = root; temp != nullptr; ) {
        auto* next = temp->next;

        delete temp;

        temp = next;
    }
}

StackItem Stack::pop() {
    auto result = *root;
    root = root->next;

    return result;
}

StackItem Stack::top() const {
    return *root;
}

void Stack::push(StackItem* item) {
    item->next = root;

    root = item;
}

bool Stack::isEmpty() const {
    return root == nullptr;
}

StackItem* Stack::getRoot() const {
    return root;
}