#ifndef STACK_H
#define STACK_H

#include "StackItem.h"

class Stack {
public:
    Stack();
    ~Stack();

    void push(StackItem*);
    StackItem pop();
    StackItem top() const;
    bool isEmpty() const;
    StackItem* getRoot() const;
private:
    StackItem* root;
};


#endif //STACK_H
